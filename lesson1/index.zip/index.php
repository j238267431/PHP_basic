<?php
    $userName = 'adminq';
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo 'Title' ?></title>
</head>
<body>
    <h1 class="rty"><?php echo 'Hello World!'; ?></h1>

    <?php

		/*
		echo $userName;
		echo $userName;
		echo $userName;
		*/
    
//    $a = 10;
//    $a += 10; //$a = $a + 10
//    $a .= 10; //$a = $a . 10
//    var_dump($a);


//    $a = (int)'100asd 1 0 dsefggsdfg sdgdfg ds';
//    var_dump(is_int($a));
//    $b = 10;
//
//    $c = $a + $b;
//    var_dump($c);

//    echo <<<php
//        <h2 class="test"> {$userName}s </h2>
//        <p style="color: red">Test</p>
//php;


//        echo "<h2> " . $userName . "</h2>";
//        echo "<h2> $userName </h2>";
//        echo '<h2> $userName </h2>';
//        echo "<h2> {$userName}s </h2>";
//        echo "<h2 class=\"test\"> {$userName}s </h2>";
    ?>
    <script>
        var a = '<?php echo 10?>';
    </script>
</body>
</html>