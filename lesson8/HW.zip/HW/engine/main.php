<?php
include 'lib.php';
// var_dump(run());
run();
// echo 'main';