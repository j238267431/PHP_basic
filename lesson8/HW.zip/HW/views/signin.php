<h2>Регистрация</h2>

<form action="?p=signin&a=signin" method="POST">
   <input type="text" name="name" placeholder="name">
   <input type="text" name="signin" placeholder="login">
   <input type="password" name="password" placeholder="password">
   <input type="submit" name="button" value="sign in">
</form>