<form action="?p=goods&a=addItem" method="post">
   <input name="name" type = "text" placeholder="название товара"><br>
   <input name="price" type = "text" placeholder="стоимость"><br>
   <textarea name="info" placeholder="краткое описание"></textarea><br>
   <input type="submit" value="добавить">
</form>