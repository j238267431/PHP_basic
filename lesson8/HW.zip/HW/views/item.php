<?php
/** var [] $goods */
?>

   <h2><?= $result['name']?></h2>
   <p><?= $result['info']?></p>
   <p><a href="?p=item&a=add&id=<?= $result['id'] ?>">add to cart</a></p>




