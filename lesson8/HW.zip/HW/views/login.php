<form action="?p=login&a=login" method="post">
   <input type ="text" name="login" placeholder="введите логин" formmethod="get">
   <input type ="password" name="password" placeholder="введите пароль" formmethod="post">
   <input type ="submit" value="login">
</form>

