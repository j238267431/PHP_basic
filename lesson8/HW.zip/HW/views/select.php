<form method="GET">
   <selector>
      <option>заказан</option>
      <option>оплачен</option>
      <option>доставлен</option>
   </selector>

</form>